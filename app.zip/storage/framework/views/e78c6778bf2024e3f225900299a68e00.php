
<div style='text-align: right;'>
    <?php if(session()->has('success')): ?>
    <p class='alert alert-success text-success mb-0'><i class='fas fa-check'></i> <?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <p class='alert alert-danger text-danger mb-0'><i class='fas fa-warning'></i> <?php echo e(session()->get('error')); ?></p>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class='alert alert-danger text-danger mb-0'><i class='fas fa-warning'></i> <?php echo e($err); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/components/main-notification.blade.php ENDPATH**/ ?>