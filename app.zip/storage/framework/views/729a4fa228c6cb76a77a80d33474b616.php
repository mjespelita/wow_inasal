<img src="<?php echo e(url('assets/logo-name.png')); ?>" alt="">
<?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/components/application-logo.blade.php ENDPATH**/ ?>