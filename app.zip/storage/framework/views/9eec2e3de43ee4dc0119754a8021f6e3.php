<a href="/">
    <img src="<?php echo e(url('assets/logo.png')); ?>" alt="" width="300px">
</a>
<?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>