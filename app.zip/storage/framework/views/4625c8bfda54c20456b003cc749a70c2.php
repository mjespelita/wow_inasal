<?php $__env->startSection('content'); ?>
    <h1>Edit Discounts</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('discounts.update', $item->id)); ?>' method='POST'>
                <?php echo csrf_field(); ?>

        <div class='form-group'>
            
            <input type='text' class='form-control' id='users_id' name='users_id' value='<?php echo e($item->users_id); ?>' required hidden>
        </div>

        <div class='form-group'>
            <label for='name'>Name</label>
            <input type='text' class='form-control' id='name' name='name' value='<?php echo e($item->name); ?>' required>
        </div>

        <div class='form-group'>
            <label for='name'>Discount</label>
            <input type='number' class='form-control' id='discount' name='discount' value='<?php echo e($item->discount); ?>' required>
        </div>

                <button type='submit' class='btn btn-primary mt-3'>Update</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/discounts/edit-discounts.blade.php ENDPATH**/ ?>