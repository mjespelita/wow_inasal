<?php $__env->startSection('content'); ?>
    <h1>Products Details</h1>

    <div class='card'>
        <div class='card-body'>
            <div class='table-responsive'>
                <table class='table'>

        <tr>
            <th>Product ID</th>
            <td><?php echo e($item->product_id); ?></td>
        </tr>

        <tr>
            <th>Name</th>
            <td><?php echo e($item->name); ?></td>
        </tr>

        <tr>
            <th>Description</th>
            <td><?php echo e($item->description); ?></td>
        </tr>

        <tr>
            <th>Price</th>
            <td>₱<?php echo e(Smark\Smark\Math::convertToMoneyFormat($item->price)); ?></td>
        </tr>

                    <tr>
                        <th>Created At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <a href='<?php echo e(route('products.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/products/show-products.blade.php ENDPATH**/ ?>