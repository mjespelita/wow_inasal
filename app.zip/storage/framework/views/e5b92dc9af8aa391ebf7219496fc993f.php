<?php $__env->startSection('content'); ?>
    <!-- Main Content Area -->
    <h1>Welcome to the Dashboard</h1>
    <b>Hello, Admin</b>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Products</h5>
                    <h1>23</h1>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Orders</h5>
                    <h1><?php echo e(App\Models\Orders::count()); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Preparing Orders</h5>
                    <h1><?php echo e(App\Models\Orders::where('status', 'preparing')->count()); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Done Orders</h5>
                    <h1><?php echo e(App\Models\Orders::where('status', 'done')->count()); ?></h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/dashboard.blade.php ENDPATH**/ ?>