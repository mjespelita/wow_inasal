<img src="<?php echo e(url('assets/logo.png')); ?>" alt="" width="100px">
<?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/components/application-mark.blade.php ENDPATH**/ ?>