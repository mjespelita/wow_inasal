<?php $__env->startSection('content'); ?>
    <h1>Discounts Details</h1>

    <div class='card'>
        <div class='card-body'>
            <div class='table-responsive'>
                <table class='table'>

        <tr>
            <th>Added by</th>
            <td><?php echo e($item->users->name ?? "no data"); ?></td>
        </tr>

        <tr>
            <th>Name</th>
            <td><?php echo e($item->name); ?></td>
        </tr>

        <tr>
            <th>Discount</th>
            <td><?php echo e($item->discount); ?>%</td>
        </tr>

                    <tr>
                        <th>Created At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <a href='<?php echo e(route('discounts.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\WowInasal\resources\views/discounts/show-discounts.blade.php ENDPATH**/ ?>