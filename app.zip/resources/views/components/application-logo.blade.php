<img src="{{ url('assets/logo-name.png') }}" alt="">
