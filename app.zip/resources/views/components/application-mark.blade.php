<img src="{{ url('assets/logo.png') }}" alt="" width="100px">
